TP de Melvin BARDIN

======
concernant les "ombre douce", 
les miennes sont très légère pour ne pas trop impacter les temps de calculs
j'ai donc joint dans le zip une image du rendu basique, et une avec des ombre plus jolie (qui m'a pris plus longtemps a calculer )

